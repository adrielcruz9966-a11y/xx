# Daitred - FastAPI

Projeto Daitred pronto para deploy (FastAPI).

## Como rodar localmente

1. Copie `.env.example` para `.env` e ajuste os valores.
2. Instale dependências:

```
pip install -r requirements.txt
```

3. Rode localmente:

```
uvicorn main:app --reload
```

4. Endpoints principais:
- `GET /api/activate?token=...&action=...`
- `GET /health`
- `POST /api/activate/admin/token` (criar token — precisa de ADMIN_KEY no header `x-admin-key`)
