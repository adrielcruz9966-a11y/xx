from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app.routers.activate import router as activate_router
from fastapi.middleware.cors import CORSMiddleware
import os

app = FastAPI(title="Daitred API")

# CORS (ajuste conforme necessário)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Monta rota pública para o script
if os.path.isdir("app/public"):
    app.mount("/public", StaticFiles(directory="app/public"), name="public")

# Rotas
app.include_router(activate_router, prefix="/api/activate")

@app.get("/health")
async def health():
    return {"ok": True}

# Mensagem simples na raiz
@app.get("/")
async def root():
    return {"status": "Daitred API pronta"}
