from app.core.config import DAITRED_TOKENS

def validate_token(token: str) -> bool:
    if not token:
        return False
    return token in DAITRED_TOKENS
