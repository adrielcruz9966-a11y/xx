import os
from dotenv import load_dotenv

load_dotenv()

DAITRED_TOKENS = [t.strip() for t in os.getenv("DAITRED_TOKENS", "").split(",") if t.strip()]
LOG_FILE = os.getenv("LOG_FILE", "logs.txt")
BASE_URL = os.getenv("BASE_URL", "http://localhost:8000")
