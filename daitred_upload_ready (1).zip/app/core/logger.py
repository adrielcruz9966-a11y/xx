import json
from app.core.config import LOG_FILE
import os

def log_access(data: dict):
    try:
        # garante pasta atual
        base = os.getcwd()
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(data) + "\n")
    except Exception as e:
        # em produção troque por logger mais robusto
        print("log error:", e)

# utilitário simples para persistir tokens (MVP)
def append_token_to_store(token: str):
    try:
        with open("tokens_store.txt", "a", encoding="utf-8") as f:
            f.write(token + "\n")
    except Exception as e:
        print("append token error:", e)
