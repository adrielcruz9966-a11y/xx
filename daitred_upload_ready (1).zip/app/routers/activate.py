from fastapi import APIRouter, Request, HTTPException, Header
from app.core.validate import validate_token
from app.core.actions import execute_action
from app.core.logger import log_access
from pydantic import BaseModel
from typing import Optional
import os

router = APIRouter()

# GET /api/activate?token=XYZ&action=liberar_botao
@router.get("/")
async def activate(request: Request, token: Optional[str] = "", action: Optional[str] = "default"):
    ip = request.headers.get("x-forwarded-for") or request.client.host

    valid = validate_token(token)

    # log mínimo
    log_access({
        "token": token,
        "ip": ip,
        "action": action,
        "valid": valid,
        "time": request.scope.get("time")
    })

    if not valid:
        raise HTTPException(status_code=403, detail={"status": "denied"})

    response = await execute_action(action)
    return response

# Admin: criar token simples (header x-admin-key: ADMIN_KEY)
class TokenCreate(BaseModel):
    token: str

@router.post("/admin/token")
async def create_token(payload: TokenCreate, x_admin_key: Optional[str] = Header(None)):
    ADMIN_KEY = os.getenv("ADMIN_KEY")
    if not ADMIN_KEY or x_admin_key != ADMIN_KEY:
        raise HTTPException(status_code=403, detail="admin_key_invalid")

    # Persiste token no arquivo .env ou em um arquivo simples (para MVP)
    # Aqui vamos anexar no LOG_FILE como registro — substitua por DB em produção
    from app.core.logger import append_token_to_store
    append_token_to_store(payload.token)

    return {"status": "ok", "token": payload.token}
