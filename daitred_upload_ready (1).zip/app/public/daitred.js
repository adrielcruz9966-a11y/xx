(function () {
  // CONFIG - troque pelo token real e URL da sua API
  var API = (function(){
    try { return window.__DAITRED_BASE || ("https://SEU-PROJETO.onrender.com"); } catch(e) { return "https://SEU-PROJETO.onrender.com"; }
  })();

  var TOKEN = "TOKEN_PRINCIPAL_AQUI";

  function safeFetch(url, cb) {
    fetch(url, { cache: "no-store" })
      .then(function (r) { return r.json(); })
      .then(function (j) { cb(null, j); })
      .catch(function (e) { cb(e); });
  }

  function executarAcao(res) {
    if (!res || res.status !== "ok") return;

    // mostrar botão
    if (res.action === "show_button") {
      var el = document.querySelector("[data-daitred]");
      if (el) el.style.display = "block";
    }

    // redirecionar
    if (res.redirect) {
      window.location.href = res.redirect;
    }

    // disparar pixel
    if (res.pixel && window.fbq) {
      try { window.fbq("track", res.pixel); } catch (e) {}
    }
  }

  function chamar(action) {
    var url = API + "/api/activate?token=" + encodeURIComponent(TOKEN) + "&action=" + encodeURIComponent(action || "default");
    safeFetch(url, function (err, res) {
      if (err) return;
      executarAcao(res);
    });
  }

  // anti-inspeção simples
  try {
    document.addEventListener("keydown", function (e) {
      if (e.key === "F12" || (e.ctrlKey && e.shiftKey && e.key === "I")) {
        e.preventDefault();
      }
    });
  } catch (e) {}

  // inicialização
  setTimeout(function () { chamar("default"); }, 400);

})();
